package aed;

public class InfoMateria{
    String[] carreras;
    String[] nombresEnCarreras;

    public InfoMateria(String[] carreras, String[] nombresEnCarreras){
        this.carreras = carreras;
        this.nombresEnCarreras = nombresEnCarreras;
    }
}